﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialNetwork.DataProcessor.ExportDTOs
{
    internal class PostDtoExportXml
    {
    }
}
