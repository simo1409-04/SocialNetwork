﻿using SocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialNetwork.DataProcessor.ExportDTOs
{
    public class ConversationsJsonDtoExport
    {

        public int Id { get; set; }


        public string Title { get; set; } = null!;

        public DateTime StartedAt { get; set; }






    }
}
