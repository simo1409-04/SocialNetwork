﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using SocialNetwork.Data;
using SocialNetwork.Data.Models;
using System.Globalization;
using System.Runtime.Serialization;

namespace SocialNetwork.DataProcessor
{
    public class Serializer
    {
        public static string ExportUsersWithFriendShipsCountAndTheirPosts(SocialNetworkDbContext dbContext)
        {
            throw new NotImplementedException();
        }

        public static string ExportConversationsWithMessagesChronologically(SocialNetworkDbContext dbContext)
        {

            List<Conversation> conversations = dbContext.Conversations.Include(x => x.Messages).ThenInclude(x=>x.Sender).OrderBy(x=>x.StartedAt).AsNoTracking().ToList();


            var conversationsForExport = conversations.Select(x => new
            {
                Id = x.Id,
                Title = x.Title,
                StartedAt = x.StartedAt.ToString("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture),
                Messages =
                x.Messages.OrderBy(m => m.SentAt).Select(m => new
                {
                    Content = m.Content,
                    SentAt = m.SentAt.ToString("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture),
                    Status = (int)m.Status,
                    SenderUsername = m.Sender.Username

                }).ToList()


            }).ToList();



            JsonSerializerSettings settings = new JsonSerializerSettings
            {

                Formatting = Formatting.Indented

            };


            return JsonConvert.SerializeObject(conversationsForExport, settings);

        }
    }
}
